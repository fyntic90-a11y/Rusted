# RUSTED — лобби (Fabric 1.17.1)

Сборка (нужна Java 16+ и интернет):
    gradle wrapper --gradle-version 7.4.2   # один раз, если нет gradlew
    ./gradlew build                          # jar: build/libs/rusted-0.1.0.jar
Положить jar в .minecraft/mods вместе с Fabric API 0.46.1+1.17.

Свои картинки (необязательно):
    src/main/resources/assets/rusted/textures/gui/background.png  — фон (иначе панорама MC)
    src/main/resources/assets/rusted/textures/gui/logo.png        — квадратный логотип

Настройки (IP сервера для ИГРАТЬ, ссылки соцсетей): RustedTitleScreen.java, вверху класса.
