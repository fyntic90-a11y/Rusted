package ru.rusted;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
import net.minecraft.util.math.MathHelper;

/** Текстовая кнопка меню в стиле Rust: серый текст, при наведении — белый + красная полоска. */
public class RustedButton extends ButtonWidget {
    private float hover = 0f;
    private final float textScale;

    public RustedButton(int x, int y, int w, int h, String label, float textScale, PressAction action) {
        super(x, y, w, h, new LiteralText(label), action);
        this.textScale = textScale;
    }

    @Override
    public void renderButton(MatrixStack m, int mx, int my, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        hover = MathHelper.lerp(0.25f, hover, isHovered() ? 1f : 0f);

        int gray = 0x8C, white = 0xFF;
        int c = (int) MathHelper.lerp(hover, gray, white);
        int color = 0xFF000000 | (c << 16) | (c << 8) | c;

        // подсветка и красная полоска слева
        int a = (int) (hover * 70);
        if (a > 0) {
            fill(m, x - 10, y, x + width, y + height, (a << 24));
        }
        fill(m, x - 10, y, x - 10 + Math.max(0, (int) (3 * hover)), y + height, 0xFFC4372B);

        float shift = hover * 4f;
        m.push();
        m.translate(x + shift, y + (height - 9 * textScale) / 2f, 0);
        m.scale(textScale, textScale, 1f);
        mc.textRenderer.drawWithShadow(m, getMessage().asString(), 0, 0, color);
        m.pop();
    }
}
