package ru.rusted;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.render.RotatingCubeMapRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;

public class RustedTitleScreen extends Screen {
    /** IP сервера для кнопки «ИГРАТЬ». Пусто = откроется выбор одиночного мира. */
    public static final String SERVER_IP = "";

    public static final String VERSION = "RUSTED v0.1.0  |  Fabric 1.17.1";
    public static final String SLOGAN = "Выживай. Дерись. Побеждай.";

    public static final String LINK_DISCORD = "https://discord.com";
    public static final String LINK_VK = "https://vk.com";
    public static final String LINK_YOUTUBE = "https://youtube.com";
    public static final String LINK_TELEGRAM = "https://t.me";
    public static final String LINK_SITE = "https://example.com";

    private static final Identifier BG = new Identifier("rusted", "textures/gui/background.png");
    private static final Identifier LOGO = new Identifier("rusted", "textures/gui/logo.png");

    private final RotatingCubeMapRenderer panorama = new RotatingCubeMapRenderer(TitleScreen.PANORAMA_CUBE_MAP);
    private long start;
    private boolean hasBg, hasLogo;

    public RustedTitleScreen() {
        super(new LiteralText("RUSTED"));
    }

    @Override
    protected void init() {
        start = Util.getMeasuringTimeMs();
        hasBg = client.getResourceManager().containsResource(BG);
        hasLogo = client.getResourceManager().containsResource(LOGO);

        float ts = Math.max(1f, height / 200f);
        int bx = (int) (width * 0.065f);
        int bw = (int) (height * 0.6f);
        int bh = (int) (height * 0.075f);
        int by = (int) (height * 0.46f);
        int step = (int) (height * 0.1f);

        addDrawableChild(new RustedButton(bx, by, bw, bh, "ИГРАТЬ", ts, b -> play()));
        addDrawableChild(new RustedButton(bx, by + step, bw, bh, "СЕРВЕРЫ", ts,
                b -> client.setScreen(new MultiplayerScreen(this))));
        addDrawableChild(new RustedButton(bx, by + step * 2, bw, bh, "НАСТРОЙКИ", ts,
                b -> client.setScreen(new OptionsScreen(this, client.options))));
        addDrawableChild(new RustedButton(bx, by + step * 3, bw, bh, "ВЫЙТИ", ts, b -> client.scheduleStop()));

        int s = Math.max(16, (int) (height * 0.055f));
        int gap = s / 3;
        int sx = width - s - 8;
        int sy = 8;
        String[] labels = {"DS", "VK", "YT", "TG", "WEB"};
        String[] urls = {LINK_DISCORD, LINK_VK, LINK_YOUTUBE, LINK_TELEGRAM, LINK_SITE};
        for (int i = 0; i < 5; i++) {
            addDrawableChild(new SocialButton(sx, sy + i * (s + gap), s, labels[i], urls[i]));
        }
    }

    private void play() {
        if (!SERVER_IP.isBlank()) {
            ConnectScreen.connect(this, client, ServerAddress.parse(SERVER_IP), null);
        } else {
            client.setScreen(new SelectWorldScreen(this));
        }
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public void render(MatrixStack m, int mx, int my, float delta) {
        float fade = MathHelper.clamp((Util.getMeasuringTimeMs() - start) / 900f, 0f, 1f);

        // фон
        if (hasBg) {
            RenderSystem.setShaderTexture(0, BG);
            drawTexture(m, 0, 0, 0, 0, width, height, width, height);
        } else {
            panorama.render(delta, 1f);
        }
        // затемнение + виньетка слева
        fillGradient(m, 0, 0, width, height, 0x80000000, 0xB0000000);
        int strips = 40;
        int zone = (int) (width * 0.65f);
        for (int i = 0; i < strips; i++) {
            int a = (int) (170 * (1f - i / (float) strips));
            fill(m, i * zone / strips, 0, (i + 1) * zone / strips, height, a << 24);
        }

        // логотип
        int L = (int) (height * 0.15f);
        int lx = (int) (width * 0.055f);
        int ly = (int) (height * 0.13f - (1f - fade) * 10);
        int alpha = Math.max(5, (int) (fade * 255)) << 24;

        if (hasLogo) {
            RenderSystem.setShaderTexture(0, LOGO);
            RenderSystem.enableBlend();
            drawTexture(m, lx, ly, 0, 0, L, L, L, L);
        } else {
            fill(m, lx, ly, lx + L, ly + L, 0xFFB5302A);
            // простой знак: три «луча» из центра
            int cx = lx + L / 2, cy = ly + L / 2, t = Math.max(2, L / 10);
            fill(m, cx - t / 2, cy - L / 3, cx + t / 2 + 1, cy + t, 0xFF1A0F0E);
            fill(m, cx - L / 3, cy - t / 2, cx - t / 2, cy + t / 2 + 1, 0xFF1A0F0E);
            fill(m, cx - t / 2, cy, cx + L / 3, cy + t, 0xFF1A0F0E);
            fill(m, cx - t, cy - t, cx + t, cy + t, 0xFF1A0F0E);
        }

        float titleScale = L / 7.5f;
        drawScaled(m, "RUSTED", lx + L + L * 0.18f, ly + (L - 9 * titleScale) / 2f - L * 0.08f,
                titleScale, 0x00D9D5CC | alpha, true);
        float subScale = Math.max(1f, L / 24f);
        drawScaled(m, "M I N E C R A F T   R U S T   P R O J E C T", lx + L + L * 0.2f,
                ly + L - 9 * subScale - L * 0.02f, subScale, 0x00A9A59E | alpha, false);
        // красная линия под логотипом
        fill(m, lx, ly + L + 6, lx + L, ly + L + 8, 0xFFC4372B);

        // кнопки/соцсети
        super.render(m, mx, my, delta);

        // низ: версия и слоган
        float fs = Math.max(1f, height / 360f);
        drawScaled(m, VERSION, 12, height - 12 - 9 * fs, fs, 0x00808080 | alpha, false);
        int sw = (int) (textRenderer.getWidth(SLOGAN) * fs);
        int rx = width - sw - 14;
        fill(m, rx - 10, height - 12 - (int) (9 * fs) - 3, rx - 8, height - 9, 0xFFC4372B);
        drawScaled(m, SLOGAN, rx, height - 12 - 9 * fs, fs, 0x00D0D0D0 | alpha, false);
    }

    private void drawScaled(MatrixStack m, String s, float x, float y, float scale, int color, boolean bold) {
        m.push();
        m.translate(x, y, 0);
        m.scale(scale, scale, 1f);
        if (bold) {
            textRenderer.drawWithShadow(m, new LiteralText(s).formatted(net.minecraft.util.Formatting.BOLD), 0, 0, color);
        } else {
            textRenderer.drawWithShadow(m, s, 0, 0, color);
        }
        m.pop();
    }
}
