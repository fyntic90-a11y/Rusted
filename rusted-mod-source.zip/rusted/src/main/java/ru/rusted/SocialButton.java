package ru.rusted;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;

/** Маленькая квадратная кнопка соцсети справа сверху. */
public class SocialButton extends ButtonWidget {
    private float hover = 0f;

    public SocialButton(int x, int y, int size, String label, String url) {
        super(x, y, size, size, new LiteralText(label), b -> Util.getOperatingSystem().open(url));
    }

    @Override
    public void renderButton(MatrixStack m, int mx, int my, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        hover = MathHelper.lerp(0.25f, hover, isHovered() ? 1f : 0f);
        int bg = hover > 0.5f ? 0xCCC4372B : 0x88000000;
        fill(m, x, y, x + width, y + height, bg);
        // рамка
        int border = 0x55FFFFFF;
        fill(m, x, y, x + width, y + 1, border);
        fill(m, x, y + height - 1, x + width, y + height, border);
        fill(m, x, y, x + 1, y + height, border);
        fill(m, x + width - 1, y, x + width, y + height, border);

        String t = getMessage().asString();
        int tw = mc.textRenderer.getWidth(t);
        mc.textRenderer.drawWithShadow(m, t, x + (width - tw) / 2f, y + (height - 8) / 2f,
                hover > 0.5f ? 0xFFFFFFFF : 0xFFBBBBBB);
    }
}
